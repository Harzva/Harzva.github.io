(function () {
  'use strict';
  const $ = id => document.getElementById(id);
  // The preview shell is currently Chinese. Standalone browsers use their
  // own language, and message content is rendered exactly as received.
  const previewChinese = /\bOpenBotPreviewLocale\/zh-CN\b/.test(navigator.userAgent);
  const english = !previewChinese && /^en\b/i.test(navigator.language || '');
  const tr = (zh, en) => english ? en : zh;
  const S = { device: null, csrf: '', bots: [], botId: '', messages: [], requests: [], timer: null,
    generation: 0, reading: false, refreshQueued: false, sending: false, pending: {}, reviewed: [],
    cache: new Map(), failures: 0, sendError: '', connection: 'checking', directoryReady: false, historyReady: false, mutation: 0, stops: new Map(), lastBotButton: '' };
  const P = { epoch: 0, phase: 'checking', request: null, claimedDeviceId: null, timer: null, poll: null, checking: false,
    writes: new Set(), uncertainWrites: 0, reviewedWrites: 0,
    failures: 0, lastPoll: -Infinity, paused: false, resumeCheck: false };
  const STORAGE = 'openbot.mobile.v1.';
  function consumePairingLink() {
    const token = new URLSearchParams(location.hash.slice(1)).get('pair') || '';
    if (location.hash) history.replaceState(null, '', location.pathname);
    return /^[A-Za-z0-9_-]{43}$/.test(token) ? token : '';
  }
  let pairingToken = consumePairingLink();
  const controllers = new Set();
  const markdown = typeof window.markdownit === 'function'
    ? window.markdownit({ html: false, linkify: false, typographer: false, breaks: true })
    : null;
  if (markdown) {
    // Model output cannot navigate the WebView or fetch images. Preserve readable labels.
    markdown.renderer.rules.link_open = () => '<span>';
    markdown.renderer.rules.link_close = () => '</span>';
    markdown.renderer.rules.image = (tokens, index) => markdown.utils.escapeHtml(tokens[index].content);
    markdown.renderer.rules.table_open = () => '<div class="table-scroll" tabindex="0"><table>\n';
    markdown.renderer.rules.table_close = () => '</table></div>\n';
  }
  const characters = window.OpenBotCharacters;
  const fallbackCharacters = ['peek', 'sprout', 'tuantuan', 'mochi', 'fold', 'capsule', 'bubble', 'clover'];
  const REMOTE_NODE_AVATAR = '__remote_node__';
  const quickEmoji = [
    ['🙂', '微笑', 'Smile'], ['👋', '打招呼', 'Wave'], ['👍', '赞', 'Thumbs up'], ['🙌', '击掌', 'High five'],
    ['✨', '闪光', 'Sparkles'], ['💡', '灵感', 'Idea'], ['❤️', '爱心', 'Heart'], ['🙏', '感谢', 'Thanks'],
    ['🎉', '庆祝', 'Celebrate'], ['✅', '完成', 'Check mark'], ['👀', '关注', 'Eyes'], ['🤔', '思考', 'Thinking']
  ];
  function avatarId(bot) {
    const validAvatar = characters?.characters.some(character => character.id === bot?.avatar);
    if (bot?.executionLocation === 'node' && bot.canSend === false) return REMOTE_NODE_AVATAR;
    if (validAvatar) return bot.avatar;
    let hash = 0;
    for (const letter of bot?.id || '') hash = (Math.imul(hash, 31) + letter.codePointAt(0)) >>> 0;
    return fallbackCharacters[hash % fallbackCharacters.length];
  }
  function paintAvatar(node, bot, size, state = 'idle') {
    const id = avatarId(bot);
    if (node.dataset.character === id && node.dataset.state === state) return;
    node.dataset.character = id;
    node.dataset.state = state;
    if (id === REMOTE_NODE_AVATAR) {
      const ns = 'http://www.w3.org/2000/svg';
      const svg = document.createElementNS(ns, 'svg');
      svg.setAttribute('viewBox', '0 0 24 24');
      svg.setAttribute('aria-hidden', 'true');
      const add = (tag, attrs) => {
        const shape = document.createElementNS(ns, tag);
        for (const [name, value] of Object.entries(attrs)) shape.setAttribute(name, value);
        svg.append(shape);
      };
      add('rect', { x: '4', y: '4', width: '16', height: '7', rx: '2', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.7' });
      add('rect', { x: '4', y: '13', width: '16', height: '7', rx: '2', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.7' });
      add('circle', { cx: '7', cy: '7.5', r: '1', fill: 'currentColor' });
      add('path', { d: 'M10 7.5h7', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.5', 'stroke-linecap': 'round' });
      add('circle', { cx: '7', cy: '16.5', r: '1', fill: 'currentColor' });
      add('path', { d: 'M10 16.5h7', fill: 'none', stroke: 'currentColor', 'stroke-width': '1.5', 'stroke-linecap': 'round' });
      node.replaceChildren(svg);
    } else if (characters) {
      // The catalog owns SVG output. Bot metadata chooses only a known ID.
      node.innerHTML = characters.svg(id, { size, state, motion: 'off', withStyle: false }).replace(/ style="[^"]*"/g, '');
    } else {
      const logo = document.createElement('img');
      logo.src = './openbot-mark.svg'; logo.alt = '';
      node.replaceChildren(logo);
    }
  }
  function icon(path) {
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg'), line = document.createElementNS(ns, 'path');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    line.setAttribute('d', path);
    svg.append(line);
    return svg;
  }
  const messageNodes = new Map();
  const scrollByBot = new Map();
  function text(id, value) {
    const node = $(id);
    if (node.textContent !== (value || '')) node.textContent = value || '';
  }
  function show(id) {
    $('mobile-web-app').dataset.screen = id;
    for (const name of ['pairing-view', 'connected-view', 'chat-view']) $(name).hidden = name !== id;
  }
  function setConnection(state) {
    S.connection = state;
    const label = {
      checking: tr('正在检查', 'Checking'),
      pairing: tr('待配对', 'Pairing'),
      online: tr('已连接', 'Connected'),
      unknown: tr('状态待确认', 'Status unconfirmed'),
      offline: tr('连接中断', 'Offline')
    }[state];
    for (const id of ['connection-indicator', 'chat-connection']) {
      $(id).dataset.state = state;
      text(id, label);
    }
  }
  function safeRead(key, fallback) { try { return JSON.parse(localStorage.getItem(STORAGE + key)) ?? fallback; } catch (_) { return fallback; } }
  function save(key, value) { localStorage.setItem(STORAGE + key, JSON.stringify(value)); }
  function clearPrivate() {
    S.generation++; S.device = null; S.csrf = ''; S.botId = ''; S.bots = []; S.messages = []; S.requests = []; S.pending = {}; S.reviewed = []; S.sendError = ''; S.cache.clear();
    for (const controller of controllers) controller.abort();
    S.stops.clear(); S.sending = false; S.directoryReady = false; S.historyReady = false; S.lastBotButton = '';
    closeEmoji();
    messageNodes.clear(); scrollByBot.clear();
    clearTimeout(S.timer);
    $('chat-input').value = ''; $('bot-search').value = ''; $('bot-search-clear').hidden = true;
    $('chat-messages').replaceChildren(); $('bot-list').replaceChildren(); $('bot-list').dataset.signature = '';
    $('network-error').hidden = true; setConnection('pairing');
    try { for (const key of Object.keys(localStorage)) if (key.startsWith(STORAGE)) localStorage.removeItem(key); } catch (_) {}
  }
  function revoked() {
    clearPrivate(); resetPairFlow(); show('pairing-view');
    renderPairFlow('retry', tr('此设备的连接已失效。可以重新请求连接。', 'This device connection is no longer valid. You can request access again.'));
  }
  async function raw(route, method = 'GET', body, allowUnconfirmedStop = false, { csrf = S.csrf, expectedId, timeoutMs = 12000 } = {}) {
    const controller = new AbortController(); controllers.add(controller);
    const timeout = timeoutMs ? setTimeout(() => controller.abort(), timeoutMs) : null;
    try {
      const response = await fetch('/api/mobile' + route, { method, credentials: 'same-origin', cache: 'no-store', redirect: 'error', signal: controller.signal,
        headers: method === 'GET' ? {} : { 'Content-Type': 'application/json', ...(csrf ? { 'X-OpenBot-CSRF': csrf } : {}),
          ...(expectedId ? { 'X-OpenBot-Pair-Request': expectedId } : {}) },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
      const value = await response.json();
      const unconfirmedStop = allowUnconfirmedStop && response.status === 200 && value?.ok === false && value.error?.code === 'AGENT_CLEANUP_FAILED';
      if (!response.ok || value?.ok === false && !unconfirmedStop) throw Object.assign(new Error('request failed'), { status: response.status, code: value?.error?.code || value?.code, uncertain: response.status >= 500 });
      return value;
    } catch (error) { if (!error.status) error.uncertain = true; throw error; }
    finally { clearTimeout(timeout); controllers.delete(controller); }
  }
  async function read(route) {
    try { return await raw(route); }
    catch (error) {
      if (error.status !== 401) throw error;
      // A failed data read is not proof that the durable browser login expired.
      // Only an authenticated session check may clear local private state.
      try { const session = await raw('/session'); S.csrf = session.csrf; }
      catch (check) { if (check.status === 401 || check.status === 403) revoked(); throw check; }
      return raw(route);
    }
  }
  function networkError(error) {
    if (!S.device) return;
    setConnection('offline');
    $('network-error').hidden = false;
    const label = $('network-error').querySelector('[data-network-message]');
    if (label) label.textContent = tr('连接中断，正在尝试恢复。消息不会自动重发。', 'Connection interrupted. Trying again without resending messages.');
    if (S.botId) renderChat();
    else if (!S.directoryReady) renderBots();
    if (error?.status === 403 && S.botId) {
      $('task-bar').dataset.state = 'warning';
      text('chat-status', tr('当前 Bot 访问被拒绝，请在电脑检查设备授权。', 'Access was denied. Check device permissions on your computer.'));
    }
  }
  function schedule() {
    clearTimeout(S.timer);
    if (!document.hidden && S.device) S.timer = setTimeout(refresh, Math.min(15000, 1500 * 2 ** Math.min(S.failures, 4)));
  }
  const active = request => ['reserved', 'accepted', 'queued', 'running', 'superseding', 'canceling'].includes(request.status);
  function draftKey(botId) { return 'draft.' + S.device.id + '.' + botId; }
  function pendingId(botId) {
    const entry = S.pending[botId];
    return typeof entry === 'string' ? entry : entry?.id;
  }
  function persistPending() { if (S.device) save('pending.' + S.device.id, S.pending); }
  function saveDraft() {
    if (!S.device || !S.botId) return;
    const value = $('chat-input').value.slice(0, 6000);
    const pending = S.pending[S.botId];
    try {
      if (pending && typeof pending === 'object') {
        pending.draft = value;
        persistPending();
      } else save(draftKey(S.botId), value);
    } catch (_) {}
  }
  function unreviewedReceipt() {
    return S.requests.findLast(row => row.status === 'unconfirmed' && !S.reviewed.includes(row.requestId));
  }
  function sentMessage(streamId, messages = S.messages) {
    if (!streamId) return;
    return messages.find(message => message.role === 'user' &&
      (message.id === 'msg_' + streamId || message.id === 'mobile_user_' + streamId));
  }
  function settlePending(botId, requestId, options = {}) {
    const entry = S.pending[botId];
    if (pendingId(botId) !== requestId) return;
    const isCurrent = S.botId === botId;
    const previousDraft = typeof entry === 'string'
      ? (isCurrent ? $('chat-input').value : safeRead(draftKey(botId), ''))
      : entry.draft;
    // Old candidates kept the submitted text in the draft. Clear only a
    // matching message tied to this receipt, never a different newer draft.
    const draft = typeof entry === 'string' && options.message?.text === previousDraft
      ? '' : previousDraft || (options.restore ? entry.text : '') || '';
    try {
      save(draftKey(botId), draft);
      delete S.pending[botId];
      persistPending();
    } catch (_) {
      S.pending[botId] = entry;
      return;
    }
    if (isCurrent && $('chat-input').value !== draft) {
      $('chat-input').value = draft;
      fitComposer();
    }
  }
  function renderBots() {
    const rawQuery = $('bot-search').value;
    $('bot-search-clear').hidden = !rawQuery;
    const query = rawQuery.trim().toLowerCase();
    const list = $('bot-list'), empty = $('bot-empty');
    list.setAttribute('aria-busy', String(!S.directoryReady && S.connection !== 'offline'));
    if (!S.directoryReady) {
      empty.hidden = false;
      text('bot-empty', S.connection === 'offline'
        ? tr('重连后读取 Bot 列表。', 'Reconnect to load your Bots.')
        : tr('正在读取 Bot 列表…', 'Loading your Bots…'));
      return;
    }
    const shown = S.bots.filter(bot => bot.name.toLowerCase().includes(query));
    const signature = JSON.stringify([query, shown]);
    if (signature === list.dataset.signature) return;
    const focusedBot = document.activeElement?.dataset.botId;
    list.dataset.signature = signature;
    const primary = query ? null : shown.find(bot => bot.primary === true);
    const ordered = primary ? [primary, ...shown.filter(bot => bot !== primary)] : shown;
    const rows = ordered.map(bot => {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'bot-list-item'; button.dataset.botId = bot.id; button.title = bot.name;
      const remote = bot.executionLocation === 'node';
      const offline = remote && bot.canSend === false;
      const readonly = !offline && bot.canSend === false;
      button.dataset.location = remote ? 'nas' : 'mac';
      button.dataset.presence = offline ? 'offline' : readonly ? 'readonly' : 'online';
      if (readonly) button.dataset.readonly = 'true';
      const avatar = document.createElement('span');
      avatar.className = 'bot-avatar'; avatar.setAttribute('aria-hidden', 'true');
      const featured = bot === primary;
      if (featured) button.classList.add('bot-list-item--featured');
      paintAvatar(avatar, bot, featured ? 96 : 50);
      const description = document.createElement('span');
      description.className = 'bot-description';
      if (featured) {
        const tag = document.createElement('span');
        tag.className = 'bot-role'; tag.textContent = tr('主 Bot', 'Primary Bot');
        description.append(tag);
      }
      const name = document.createElement('span'); name.className = 'bot-list-name'; name.textContent = bot.name; name.title = bot.name;
      const titleRow = document.createElement('span'); titleRow.className = 'bot-title-row';
      const location = document.createElement('span');
      location.className = 'bot-location'; location.dataset.location = remote ? 'nas' : 'mac';
      location.textContent = remote ? 'NAS' : 'Mac';
      const status = offline ? tr('离线', 'Offline') : readonly ? tr('只读', 'Read only') : tr('在线', 'Online');
      titleRow.append(name);
      if (offline || readonly) {
        const availability = document.createElement('span');
        availability.className = 'bot-presence';
        availability.dataset.state = offline ? 'offline' : 'readonly';
        availability.textContent = status;
        titleRow.append(availability);
      }
      const detail = document.createElement('span'); detail.className = 'bot-list-meta';
      detail.append(location);
      const detailText = offline ? tr('仅可查看历史', 'History only')
        : remote ? tr('浏览器任务 · 结果同步到 Mac', 'Browser tasks · results sync to Mac')
          : readonly ? tr('请在电脑端交办', 'Send from your computer') : '';
      button.setAttribute('aria-label', [
        bot.name, featured ? tr('主 Bot', 'Primary Bot') : '', location.textContent, status, detailText
      ].filter(Boolean).join(tr('，', ', ')));
      if (detailText) {
        const summary = document.createElement('span');
        summary.className = 'bot-list-meta-detail'; summary.textContent = detailText;
        detail.append(summary);
      }
      const chevron = icon(featured ? 'M6 12h12m-5-5 5 5-5 5' : 'm9 6 6 6-6 6');
      chevron.setAttribute('class', 'bot-chevron');
      description.append(titleRow, detail); button.append(avatar, description, chevron);
      button.addEventListener('click', () => openBot(bot.id));
      return button;
    });
    list.replaceChildren(...rows);
    if (focusedBot) rows.find(row => row.dataset.botId === focusedBot)?.focus({ preventScroll: true });
    empty.hidden = rows.length > 0;
    empty.textContent = query
      ? tr('没有匹配的 Bot。试试其他关键词。', 'No matching Bots. Try another search.')
      : tr('没有可用的 Bot。请在 OpenBot 桌面端检查设备授权。', 'No Bots are available. Check device access on your computer.');
  }

  const timeFormat = new Intl.DateTimeFormat(english ? 'en' : 'zh-CN', { hour: '2-digit', minute: '2-digit' });
  function messageRow(entry, previous) {
    const { kind, value, ts, delivery, collab = false } = entry;
    const bot = S.bots.find(item => item.id === S.botId);
    const authorName = bot?.name || 'Bot', character = avatarId(bot);
    if (previous && previous.kind === kind && previous.value === value && previous.ts === ts &&
        previous.authorName === authorName && previous.character === character && previous.delivery === delivery && previous.collab === collab) return previous;
    const row = previous?.row || document.createElement('article');
    row.className = 'chat-message chat-message--' + (kind === 'stream' ? 'bot chat-message--stream' : kind);
    if (collab) row.dataset.collab = 'receipt';
    else delete row.dataset.collab;
    const meta = document.createElement('div');
    meta.className = 'message-meta';
    if (kind !== 'user') {
      const avatar = document.createElement('span');
      avatar.className = 'message-avatar'; avatar.setAttribute('aria-hidden', 'true');
      paintAvatar(avatar, bot, 26, kind === 'stream' ? 'thinking' : 'idle');
      meta.append(avatar);
    }
    const author = document.createElement('span');
    author.className = 'message-author';
    author.textContent = kind === 'user' ? tr('你', 'You') : authorName;
    meta.append(author);
    if (delivery && kind === 'user') {
      const badge = document.createElement('span');
      badge.className = 'message-delivery';
      badge.textContent = delivery;
      meta.append(badge);
    }
    if (kind === 'stream') {
      const live = document.createElement('span');
      live.className = 'stream-label';
      live.textContent = delivery || tr('回复中', 'Replying');
      if (delivery) live.dataset.paused = 'true';
      meta.append(live);
    }
    if (Number.isFinite(ts) && ts > 0 && ts < 8.64e15) {
      const time = document.createElement('time'), date = new Date(ts);
      time.dateTime = date.toISOString(); time.textContent = timeFormat.format(date); meta.append(time);
    }
    const body = document.createElement('div');
    body.className = 'message-body';
    if (collab) body.dataset.collabLabel = tr('多端协作回执', 'Collaboration Receipt');
    if (kind === 'user' || !markdown) {
      body.textContent = value;
    } else {
      body.classList.add('markdown');
      // HTML, linkification, images and link navigation are disabled above.
      body.innerHTML = markdown.render(value);
      body.querySelectorAll('pre').forEach(pre => {
        const frame = document.createElement('figure');
        const toolbar = document.createElement('figcaption');
        const hint = document.createElement('span');
        const copy = document.createElement('button');
        frame.className = 'code-frame';
        toolbar.className = 'code-toolbar';
        hint.className = 'code-scroll-hint'; hint.hidden = true;
        hint.append(icon('M4 12h16m-12-4-4 4 4 4m8-8 4 4-4 4'), document.createTextNode(tr('横滑查看长行', 'Swipe for long lines')));
        copy.className = 'code-copy'; copy.type = 'button';
        const copyLabel = tr('复制代码', 'Copy code');
        copy.textContent = copyLabel;
        let resetCopy;
        copy.addEventListener('click', async () => {
          const code = pre.querySelector('code') || pre;
          let copied = false;
          try {
            if (navigator.clipboard?.writeText) {
              await navigator.clipboard.writeText(code.textContent);
              copied = true;
            }
          } catch (_) {}
          if (!copied) {
            const selection = document.getSelection();
            if (selection) {
              const previous = Array.from({ length: selection.rangeCount }, (_, i) => selection.getRangeAt(i));
              const range = document.createRange();
              range.selectNodeContents(code);
              selection.removeAllRanges(); selection.addRange(range);
              try { copied = document.execCommand('copy'); } catch (_) {}
              selection.removeAllRanges();
              previous.forEach(saved => selection.addRange(saved));
            }
          }
          copy.textContent = copied ? tr('已复制', 'Copied') : tr('请长按选择复制', 'Select code to copy');
          clearTimeout(resetCopy);
          resetCopy = setTimeout(() => { copy.textContent = copyLabel; }, 1800);
        });
        pre.tabIndex = 0;
        pre.addEventListener('scroll', () => updateCodeHint(frame, pre, hint), { passive: true });
        pre.before(frame); toolbar.append(hint, copy); frame.append(toolbar, pre);
      });
    }
    row.replaceChildren(meta, body);
    return { row, kind, value, ts, authorName, character, delivery, collab };
  }
  function atLatest() {
    const list = $('chat-messages');
    return list.scrollHeight - list.scrollTop - list.clientHeight < 64;
  }
  function updateLatest() { $('chat-jump').hidden = atLatest(); }
  let hintFrame;
  function updateCodeHint(frame, pre, hint) {
    const canScroll = pre.scrollWidth - pre.clientWidth - pre.scrollLeft > 2;
    frame.dataset.canScroll = String(canScroll);
    hint.hidden = !canScroll;
  }
  function measureCodeHints() {
    if (hintFrame) return;
    hintFrame = requestAnimationFrame(() => {
      hintFrame = null;
      for (const frame of $('chat-messages').querySelectorAll('.code-frame')) {
        updateCodeHint(frame, frame.lastElementChild, frame.querySelector('.code-scroll-hint'));
      }
    });
  }
  if (typeof ResizeObserver === 'function') new ResizeObserver(measureCodeHints).observe($('chat-messages'));
  document.fonts?.ready.then(measureCodeHints);
  function jumpLatest() {
    const list = $('chat-messages');
    list.scrollTop = list.scrollHeight;
    updateLatest();
  }
  function renderMessages(pinned) {
    const list = $('chat-messages'), scrollTop = list.scrollTop;
    const listTop = list.getBoundingClientRect().top;
    const anchor = !pinned && [...list.children].find(row => row.getBoundingClientRect().bottom > listTop);
    const offset = anchor ? anchor.getBoundingClientRect().top : 0;
    const entries = new Map();
    let changed = false;
    const pending = S.pending[S.botId];
    const id = pendingId(S.botId);
    const receipt = id ? S.requests.find(request => request.requestId === id) : unreviewedReceipt();
    const durableMessage = sentMessage(receipt?.streamId || pending?.streamId);
    const delivery = receipt && receipt.status !== 'unconfirmed' ? ''
      : durableMessage ? tr('消息已保存', 'Message saved')
      : S.sending && S.connection !== 'offline' ? tr('提交中', 'Submitting') : tr('发送待确认', 'Delivery unconfirmed');
    S.messages.forEach((message, index) => {
      const kind = message.role === 'user' ? 'user' : 'bot';
      const key = kind + ':' + (message.id || index);
      const value = message.text || tr('此消息包含附件，请在电脑查看。', 'This message contains an attachment. View it on your computer.');
      entries.set(key, { kind, value, ts: message.ts, collab: message.kind === 'collaboration-receipt', delivery: message === durableMessage ? delivery : '' });
    });
    if (!durableMessage && pending?.text) {
      entries.set('pending:' + pending.id, { kind: 'user', value: pending.text, ts: pending.createdAt, delivery });
    }
    for (const request of S.requests) {
      if (active(request) && request.progress && !S.messages.some(message => message.role === 'bot' && message.runId && message.runId === request.streamId)) {
        entries.set('stream:' + request.requestId, { kind: 'stream', value: request.progress,
          delivery: S.connection === 'offline' ? tr('等待同步', 'Awaiting sync') : '' });
      }
    }
    for (const [key, cached] of messageNodes) {
      if (!entries.has(key)) { cached.row.remove(); messageNodes.delete(key); changed = true; }
    }
    if (!entries.size) {
      if (!list.firstElementChild) {
        const empty = document.createElement('p'); empty.className = 'chat-empty'; list.append(empty);
      }
      list.firstElementChild.textContent = S.historyReady
        ? tr('从这里开始对话，消息也会保存在电脑上。', 'Start a conversation here. Messages are also saved on your computer.')
        : tr('正在读取会话…', 'Loading conversation…');
    } else {
      list.querySelector('.chat-empty')?.remove();
      let next = list.firstElementChild;
      for (const [key, entry] of entries) {
        const previous = messageNodes.get(key);
        const cached = messageRow(entry, previous);
        changed ||= cached !== previous;
        messageNodes.set(key, cached);
        if (cached.row !== next) list.insertBefore(cached.row, next);
        next = cached.row.nextElementSibling;
      }
    }
    if (changed) measureCodeHints();
    if (pinned) jumpLatest();
    else {
      list.scrollTop = anchor?.isConnected ? scrollTop + anchor.getBoundingClientRect().top - offset : scrollTop;
      updateLatest();
    }
  }
  function fitComposer() {
    const input = $('chat-input');
    input.style.height = 'auto';
    input.style.height = input.scrollHeight + 2 + 'px';
    $('chat-form').dataset.hasText = input.value.trim().length > 0 ? 'true' : 'false';
  }
  function renderChat() {
    if (!S.botId) return;
    const pinned = atLatest();
    const current = S.requests.findLast(r => active(r));
    const pending = pendingId(S.botId);
    const receipt = S.requests.find(r => r.requestId === pending);
    const pendingUnconfirmed = pending && (!receipt || receipt.status === 'unconfirmed');
    const unconfirmed = unreviewedReceipt();
    const uncertain = pendingUnconfirmed || !!unconfirmed;
    const uncertainStream = pendingUnconfirmed ? receipt?.streamId || S.pending[S.botId]?.streamId : unconfirmed?.streamId;
    const savedWithUnknownTask = uncertain && !!sentMessage(uncertainStream);
    const last = S.requests.at(-1);
    const bot = S.bots.find(b => b.id === S.botId);
    const stop = S.stops.get(S.botId);
    const stopping = stop && current?.requestId === stop.requestId ? stop : null;
    const stopUnconfirmed = stop && last?.requestId === stop.requestId && last.status === 'unconfirmed';
    const offline = S.connection === 'offline';
    const readOnly = bot?.canSend === false;
    const waiting = uncertain || stopUnconfirmed || stopping?.phase === 'unknown';
    const taskState = offline ? (waiting || current || S.sending ? 'offline' : 'idle')
      : waiting && !S.sending ? 'uncertain' : current || S.sending ? 'active' :
      S.sendError ? 'warning' : last ? 'result' : readOnly ? 'warning' : 'idle';
    $('task-bar').dataset.state = taskState;
    paintAvatar($('chat-avatar'), bot, 40, offline ? 'rest' : waiting ? 'peeking' : current ? 'thinking' :
      last?.status === 'succeeded' ? 'done' : 'idle');
    const stopButton = $('chat-stop');
    stopButton.hidden = offline || !current;
    stopButton.disabled = offline || !current || !!stopping || current?.status === 'canceling';
    stopButton.setAttribute('aria-label', stopping?.phase === 'sending' || current?.status === 'canceling'
      ? tr('停止中', 'Stopping') : tr('停止', 'Stop'));
    text('stop-label', stopButton.getAttribute('aria-label'));
    $('chat-review').hidden = offline || !uncertain || !!current || S.sending;
    text('chat-review', stopUnconfirmed || savedWithUnknownTask
      ? tr('核查任务', 'Review task') : tr('核查未确认的发送', 'Review unconfirmed message'));
    $('chat-send').hidden = !stopButton.hidden;
    $('chat-send').disabled = !S.historyReady || offline || S.sending || !!current || !!pending || !!uncertain || readOnly;
    $('chat-input').disabled = readOnly;
    $('chat-input').readOnly = S.sending && !!pending;
    $('emoji-toggle').disabled = readOnly || $('chat-input').readOnly;
    if (readOnly) closeEmoji();
    $('chat-input').placeholder = bot?.executionLocation === 'node' ? tr('交办远端浏览器任务…', 'Describe a remote browser task…') : tr('发送消息…', 'Send a message…');
    text('chat-destination', bot?.executionLocation === 'node' ? tr('远端节点', 'Remote node') : 'Mac');
    text('chat-status',
      offline ? (stop ? tr('重连后核对原任务的停止结果。', 'Reconnect to check whether the original task stopped.')
        : savedWithUnknownTask ? tr('消息已保存。重连后核对原任务状态。', 'Message saved. Reconnect to check the original task.')
        : uncertain ? tr('发送待确认。重连后核对这条消息。', 'Delivery unconfirmed. Reconnect to check this message.')
        : current || S.sending ? tr('重连后同步原任务状态。', 'Reconnect to sync the original task.') : '') :
      stopUnconfirmed ? tr('停止结果尚未确认。请在电脑核查原任务。', 'Stop is unconfirmed. Check the original task on your computer.') :
      stopping?.phase === 'unknown' ? tr('停止结果待确认，正在核查原任务。', 'Stop is unconfirmed. Checking the original task.') :
      stopping || current?.status === 'canceling' ? tr('正在停止 · 等待执行端确认', 'Stopping · waiting for the executor') :
      current?.status === 'queued' ? tr('任务已排队', 'Task queued') :
      current ? tr('正在处理 · 如需授权，请在 Mac 确认', 'Working · confirm any permission requests on your Mac') :
      S.sending ? tr('正在提交…', 'Submitting…') :
      savedWithUnknownTask ? tr('消息已保存，任务状态待确认。请核查原任务。', 'Message saved. Check the original task to confirm its state.') :
      uncertain ? tr('发送待确认。请核对当前会话，消息不会自动重发。', 'Delivery unconfirmed. Check this conversation. The message will not be resent automatically.') :
      S.sendError || (readOnly ? (bot.executionLocation === 'node' ? tr('请先在 Mac 连接此 Bot 的节点。', 'Connect this Bot’s node on your Mac first.') : tr('此 Bot 请在电脑上交办。', 'Send tasks to this Bot from your computer.')) :
      last?.status === 'canceled' ? tr('已停止', 'Stopped') : ['failed', 'blocked', 'interrupted'].includes(last?.status) ? tr('本次任务未完成，请在 Mac 查看任务详情。', 'This task did not complete. Check its details on your Mac.') : last?.status === 'succeeded' ? tr('已完成 · 结果已保存到同一会话', 'Complete · result saved to this conversation') :
      bot?.executionLocation === 'node' ? tr('由远端节点执行浏览器任务，结果同步到 Mac。', 'The remote node runs browser tasks. Results sync with your Mac.') : tr('与 Mac 使用同一段对话', 'The same conversation as your Mac')));
    renderMessages(pinned);
  }
  async function refresh() {
    if (S.reading) { S.refreshQueued = true; return; }
    if (!S.device || document.hidden) { schedule(); return; }
    const generation = S.generation, botId = S.botId; S.reading = true;
    try {
      const list = await read('/bots');
      if (generation !== S.generation) return;
      S.bots = list.bots; S.directoryReady = true; renderBots();
      if (botId) {
        const mutation = S.mutation;
        const data = await read('/bots/' + encodeURIComponent(botId) + '/history');
        if (generation !== S.generation || botId !== S.botId) return;
        // A read started before a write acknowledgment may still contain the old task state.
        if (mutation !== S.mutation) { S.refreshQueued = true; return; }
        S.messages = data.messages; S.requests = data.requests; S.historyReady = true;
        const stop = S.stops.get(botId);
        if (stop && stop.phase !== 'sending') {
          const receipt = data.requests.find(r => r.requestId === stop.requestId);
          if (receipt && receipt.status !== 'unconfirmed' &&
              (!active(receipt) || receipt.status === 'canceling' || stop.phase === 'unknown')) S.stops.delete(botId);
        }
        S.cache.delete(botId); S.cache.set(botId, { at: Date.now(), messages: data.messages });
        while (S.cache.size > 3) S.cache.delete(S.cache.keys().next().value);
        const pending = pendingId(botId);
        if (pending) {
          const receipt = data.requests.find(r => r.requestId === pending);
          const entry = S.pending[botId];
          const message = sentMessage(receipt?.streamId);
          if (receipt && receipt.status !== 'unconfirmed') settlePending(botId, pending, { message });
          else if (message && entry?.text && entry.streamId !== receipt.streamId) {
            // Keep the identity when this Bot's history is reopened from cache.
            entry.streamId = receipt.streamId;
            try { persistPending(); } catch (_) {}
          } else if (message && typeof entry === 'string' && $('chat-input').value === message.text) {
            // A legacy pending request already visible in history stays locked,
            // but its text no longer also appears as an editable draft.
            $('chat-input').value = '';
            fitComposer(); saveDraft();
          }
        }
      }
      S.failures = 0; $('network-error').hidden = true; setConnection('online');
      renderChat();
    } catch (error) { if (generation === S.generation) { S.failures++; networkError(error); } }
    finally {
      S.reading = false;
      if (S.refreshQueued) { S.refreshQueued = false; void refresh(); }
      else schedule();
    }
  }
  function openBot(botId) {
    saveDraft(); S.generation++; S.botId = botId; S.requests = []; S.sendError = '';
    S.historyReady = false; S.lastBotButton = botId;
    $('chat-messages').replaceChildren(); messageNodes.clear();
    // Cached display is bounded and every navigation still checks the server.
    const cached = S.cache.get(botId); S.messages = cached && Date.now() - cached.at < 300000 ? cached.messages : [];
    text('chat-bot-name', S.bots.find(b => b.id === botId)?.name || 'Bot');
    const pending = S.pending[botId];
    $('chat-input').value = pending && typeof pending === 'object' ? pending.draft : safeRead(draftKey(botId), '');
    show('chat-view'); fitComposer(); renderChat();
    const scroll = scrollByBot.get(botId);
    if (cached && scroll !== undefined) { $('chat-messages').scrollTop = scroll; updateLatest(); }
    $('chat-bot-name').focus({ preventScroll: true });
    void refresh();
  }
  async function connected(session) {
    if (!session?.device?.id || typeof session.csrf !== 'string' || !session.csrf) throw new Error('Invalid mobile session');
    resetPairFlow();
    S.device = session.device; S.csrf = session.csrf; S.pending = safeRead('pending.' + S.device.id, {});
    if (!S.pending || typeof S.pending !== 'object' || Array.isArray(S.pending)) S.pending = {};
    S.reviewed = safeRead('reviewed.' + S.device.id, []); if (!Array.isArray(S.reviewed)) S.reviewed = [];
    show('connected-view'); setConnection('checking'); pairingToken = ''; text('pair-status', '');
    renderBots();
    $('connected-title').focus({ preventScroll: true });
    await refresh();
  }
  function defaultDeviceName() {
    const agent = navigator.userAgent || '';
    if (/iPad/i.test(agent) || navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1) return tr('我的 iPad', 'My iPad');
    if (/iPhone/i.test(agent)) return tr('我的 iPhone', 'My iPhone');
    if (/Android/i.test(agent)) return tr('我的 Android 手机', 'My Android phone');
    return tr('我的手机', 'My phone');
  }
  function resetPairFlow() {
    P.epoch++; clearTimeout(P.timer); P.request = null; P.claimedDeviceId = null; P.checking = false;
    P.failures = 0; P.lastPoll = -Infinity; P.resumeCheck = false;
  }
  function pairDeadline(work) {
    let timer;
    const deadline = new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('Pairing response still pending')), 12000); });
    return Promise.race([work, deadline]).finally(() => clearTimeout(timer));
  }
  function trackPairWrite(route, body, expectedId, csrf) {
    // A page-generation check cannot undo Set-Cookie. Keep the underlying
    // browser fetch in the barrier even if the UI stops waiting for it.
    const write = raw(route, 'POST', body, false, { csrf, expectedId, timeoutMs: 0 });
    P.writes.add(write);
    const finish = () => { P.writes.delete(write); if (P.poll === write) P.poll = null; };
    write.then(finish, error => { if (!error.status) P.uncertainWrites++; finish(); });
    return write;
  }
  function settlePairWrites() {
    return pairDeadline(Promise.allSettled([...P.writes]));
  }
  function renderPairFlow(phase, status = '') {
    P.phase = phase;
    const qr = phase === 'qr' || phase === 'qr-sending';
    const form = ['checking', 'idle', 'retry', 'sending', 'qr', 'qr-sending'].includes(phase);
    const waiting = ['waiting', 'canceling', 'cancel-unknown'].includes(phase) && !!P.request;
    const check = ['check-failed', 'recover-request', 'already-connected', 'pair-changed', 'qr-unknown'].includes(phase) ||
      phase === 'waiting' && P.failures > 0;
    const cancel = ['waiting', 'canceling', 'cancel-unknown', 'already-connected', 'disconnecting'].includes(phase);
    $('pair-form').hidden = !form;
    $('pair-device-name').disabled = phase === 'sending' || phase === 'qr-sending';
    $('pair-connect').disabled = !['idle', 'retry', 'qr'].includes(phase);
    text('pair-connect', phase === 'retry' ? tr('重新请求连接', 'Request access again')
      : qr ? tr('确认连接', 'Confirm connection') : tr('请求连接', 'Request access'));
    text('pair-intro', qr ? tr('确认后连接电脑允许的 Bot。', 'Connect to the Bots authorized by your computer.')
      : tr('请求连接后，在电脑的「手机网页」中批准这台设备。', 'After requesting access, approve this device in Mobile web on your computer.'));
    $('pair-waiting').hidden = !waiting;
    text('pair-request-name', waiting ? P.request.name : '');
    text('pair-match-code', waiting ? P.request.matchCode : '');
    $('pair-actions').hidden = !check && !cancel;
    $('pair-check').hidden = !check;
    $('pair-check').disabled = P.checking;
    text('pair-check', phase === 'already-connected' ? tr('继续连接', 'Continue connection') : tr('检查状态', 'Check status'));
    $('pair-cancel').hidden = !cancel;
    $('pair-cancel').disabled = phase === 'canceling' || phase === 'disconnecting';
    text('pair-cancel', ['already-connected', 'disconnecting'].includes(phase) ? tr('退出此连接', 'Disconnect this device')
      : phase === 'cancel-unknown' ? tr('重试取消', 'Retry cancellation') : tr('取消请求', 'Cancel request'));
    text('pair-status', status);
    setConnection(['checking', 'sending', 'qr-sending', 'disconnecting'].includes(phase) ? 'checking'
      : ['check-failed', 'recover-request', 'cancel-unknown', 'pair-changed', 'qr-unknown'].includes(phase) ||
        phase === 'waiting' && P.failures > 0 ? 'unknown' : 'pairing');
  }
  function pairCurrent(epoch) { return P.epoch === epoch && !P.paused && !S.device; }
  function nextPairPoll() {
    clearTimeout(P.timer);
    if (P.phase !== 'waiting' || P.paused || document.hidden || P.checking) return;
    const interval = Math.min(30000, 2000 * 2 ** P.failures);
    P.timer = setTimeout(() => { void checkPairRequest(); }, Math.max(0, P.lastPoll + interval - performance.now()));
  }
  const pairNotFound = () => tr('电脑已找不到这次连接请求。可以重新请求连接。', 'The computer can no longer find this request. You can request access again.');
  const pairNetworkUnknown = () => tr('暂时无法确认请求状态。可以稍后检查。', 'Could not confirm the request status. You can check it again later.');
  function pairingChanged() {
    return Object.assign(new Error('Pairing request changed'), { status: 409, code: 'MOBILE_PAIRING_CHANGED' });
  }
  function showPairingChanged() {
    resetPairFlow();
    renderPairFlow('pair-changed', tr('此页面的连接请求已变化。请检查当前请求后再继续。', 'This page’s connection request changed. Check the current request before continuing.'));
  }
  function showQrUncertain() {
    renderPairFlow('qr-unknown', tr('暂时无法确认之前的连接。请先检查状态，再使用此配对链接。', 'Could not confirm the previous connection. Check its status before using this pairing link.'));
  }
  function verifyPairRequest(request, expectedId) {
    if (!request || !/^cp_[a-f0-9]{32}$/.test(request.id) || typeof request.name !== 'string' ||
        typeof request.matchCode !== 'string' || !/^\d{6}$/.test(request.matchCode)) throw new Error('Invalid pairing status');
    if (expectedId && request.id !== expectedId) throw pairingChanged();
    return request;
  }
  async function applyPairStatus(value, fromStart = false) {
    const request = verifyPairRequest(value.request, fromStart ? null : P.request?.id);
    const messages = {
      denied: tr('电脑拒绝了这次连接请求。', 'The computer denied this connection request.'),
      canceled: tr('已取消连接请求。', 'The connection request was canceled.'),
      expired: tr('这次连接请求已过期。', 'This connection request expired.'),
      revoked: tr('电脑已撤销此设备的连接。', 'The computer revoked this device connection.')
    };
    if (Object.hasOwn(messages, request.status)) {
      resetPairFlow(); P.request = request; renderPairFlow('retry', messages[request.status]); return;
    }
    if (request.status === 'connected' && !fromStart) {
      await connected(value); return;
    }
    if (!['pending', 'approved', 'connected'].includes(request.status)) throw new Error('Invalid pairing state');
    const first = P.phase !== 'waiting';
    P.request = request; P.failures = 0;
    renderPairFlow('waiting', request.status === 'pending' ? '' : tr('正在打开已批准的连接…', 'Opening the approved connection…'));
    if (first && fromStart) $('pair-wait-title').focus({ preventScroll: true });
  }
  async function checkPairRequest() {
    if (P.checking || P.paused || document.hidden || !['checking', 'waiting', 'recover-request'].includes(P.phase)) return;
    clearTimeout(P.timer);
    const epoch = P.epoch, wasWaiting = P.phase === 'waiting', wasRecovery = P.phase === 'recover-request';
    P.checking = true; P.lastPoll = performance.now(); $('pair-check').disabled = true;
    const poll = P.poll || (P.poll = trackPairWrite('/pair-requests/status', {}, P.request?.id));
    try {
      const value = await pairDeadline(poll);
      if (!pairCurrent(epoch)) return;
      await applyPairStatus(value);
    } catch (error) {
      if (!pairCurrent(epoch)) return;
      if (error.code === 'MOBILE_PAIRING_CHANGED') {
        showPairingChanged();
      } else if (error.status === 404) {
        resetPairFlow(); renderPairFlow(wasWaiting || wasRecovery ? 'retry' : 'idle', wasWaiting || wasRecovery ? pairNotFound() : '');
      } else if (wasWaiting) {
        P.failures = Math.min(P.failures + 1, 4); renderPairFlow('waiting', pairNetworkUnknown());
      } else {
        renderPairFlow('recover-request', pairNetworkUnknown());
      }
    } finally {
      if (pairCurrent(epoch)) { P.checking = false; $('pair-check').disabled = false; nextPairPoll(); }
    }
  }
  async function restorePairFlow() {
    if (P.paused || S.device || P.checking) return;
    resetPairFlow(); const epoch = P.epoch;
    P.checking = true; renderPairFlow('checking');
    try {
      await settlePairWrites();
      if (!pairCurrent(epoch)) return;
      const session = await raw('/session');
      if (pairCurrent(epoch)) await connected(session);
    } catch (error) {
      if (!pairCurrent(epoch)) return;
      P.checking = false;
      if (error.status === 401) {
        clearPrivate();
        if (pairingToken) {
          if (P.uncertainWrites > P.reviewedWrites) showQrUncertain();
          else renderPairFlow('qr');
        } else await checkPairRequest();
      }
      else if (pairingToken) showQrUncertain();
      else renderPairFlow('check-failed', tr('暂时无法连接 OpenBot。请检查手机网络，并确认电脑上的手机网页已开启。', 'Could not reach OpenBot. Check your phone’s network and make sure Mobile web is enabled on your computer.'));
    }
  }
  $('pair-form').addEventListener('submit', async event => {
    event.preventDefault();
    const phase = P.phase;
    if (S.device || P.paused || !['idle', 'retry', 'qr'].includes(phase)) return;
    const priorRequest = P.request;
    resetPairFlow();
    const epoch = P.epoch, token = pairingToken;
    const deviceName = $('pair-device-name').value.trim() || defaultDeviceName();
    if (phase === 'qr' && token) {
      renderPairFlow('qr-sending', tr('正在确认配对…', 'Confirming pairing…'));
      try {
        await settlePairWrites();
        if (!pairCurrent(epoch)) return;
        const session = await raw('/session');
        if (pairCurrent(epoch)) await connected(session);
        return;
      } catch (error) {
        if (!pairCurrent(epoch)) return;
        if (error.status !== 401 || P.uncertainWrites > P.reviewedWrites) { showQrUncertain(); return; }
      }
      pairingToken = '';
      try {
        const session = await pairDeadline(trackPairWrite('/pair', { token, deviceName }));
        if (pairCurrent(epoch)) await connected(session);
      } catch (error) {
        if (!pairCurrent(epoch)) return;
        if (error.status >= 400 && error.status < 500) {
          renderPairFlow('retry', tr('未能使用此配对链接。可以直接请求连接，或打开电脑生成的新链接。', 'Could not use this pairing link. Request access here or open a new link from your computer.'));
        } else {
          // The browser may already have accepted Set-Cookie even though
          // the QR response could not be read. Recheck before a new start.
          renderPairFlow('check-failed', tr('未能确认二维码连接结果。请先检查状态，再重新请求连接。', 'Could not confirm the QR connection. Check its status before requesting access again.'));
        }
      }
      return;
    }
    renderPairFlow('sending', tr('正在发送连接请求…', 'Sending the connection request…'));
    try {
      await settlePairWrites();
      if (!pairCurrent(epoch)) return;
      const result = await pairDeadline(trackPairWrite('/pair-requests', { deviceName }, priorRequest?.id));
      if (!pairCurrent(epoch)) return;
      P.lastPoll = performance.now();
      await applyPairStatus(result, true);
      nextPairPoll();
    } catch (error) {
      if (!pairCurrent(epoch)) return;
      P.request = priorRequest;
      if (error.code === 'MOBILE_PAIRING_CHANGED') showPairingChanged();
      else if (error.status === 429) renderPairFlow('retry', tr('请求过于频繁。请稍等后重试。', 'Too many requests. Wait a moment and try again.'));
      else if (error.status === 400) renderPairFlow('retry', tr('请检查设备名称后重试。', 'Check the device name and try again.'));
      else if (error.status === 401 || error.status === 404) renderPairFlow('retry', tr('电脑暂不支持直接请求连接。请更新电脑上的 OpenBot 后重试。', 'The computer does not support connection requests yet. Update OpenBot on your computer and try again.'));
      else renderPairFlow('recover-request', tr('未能确认请求是否发出。请先检查状态。', 'Could not confirm whether the request was sent. Check its status first.'));
    }
  });
  $('pair-check').addEventListener('click', async () => {
    if (P.phase === 'qr-unknown') P.reviewedWrites = P.uncertainWrites;
    if (['check-failed', 'pair-changed', 'qr-unknown'].includes(P.phase)) { void restorePairFlow(); return; }
    if (P.phase !== 'already-connected') { void checkPairRequest(); return; }
    const epoch = ++P.epoch;
    $('pair-check').disabled = true;
    try {
      await settlePairWrites();
      if (!pairCurrent(epoch)) return;
      const session = await raw('/session');
      if (!pairCurrent(epoch)) return;
      if (session.device?.id !== P.claimedDeviceId) throw pairingChanged();
      await connected(session);
    } catch (error) {
      if (!pairCurrent(epoch)) return;
      if (error.code === 'MOBILE_PAIRING_CHANGED') showPairingChanged();
      else renderPairFlow(error.status === 401 ? 'retry' : 'already-connected',
        error.status === 401 ? tr('连接已失效，可以重新请求。', 'The connection expired. You can request access again.') : pairNetworkUnknown());
    }
  });
  $('pair-cancel').addEventListener('click', async () => {
    if (!['waiting', 'cancel-unknown', 'already-connected'].includes(P.phase)) return;
    const disconnect = P.phase === 'already-connected', epoch = ++P.epoch;
    clearTimeout(P.timer); P.checking = false;
    renderPairFlow(disconnect ? 'disconnecting' : 'canceling',
      disconnect ? tr('正在退出连接…', 'Disconnecting…') : tr('正在取消请求…', 'Canceling the request…'));
    try {
      if (disconnect) {
        // An older poll may already have claimed the request. Let its browser
        // cookie settle before an explicitly requested disconnect.
        await settlePairWrites();
        if (!pairCurrent(epoch)) return;
        const session = await raw('/session');
        if (!pairCurrent(epoch)) return;
        if (session.device?.id !== P.claimedDeviceId) throw pairingChanged();
        await pairDeadline(trackPairWrite('/logout', {}, null, session.csrf));
        if (!pairCurrent(epoch)) return;
        clearPrivate(); resetPairFlow(); renderPairFlow('retry', tr('已退出连接。', 'Disconnected.'));
      } else {
        const expectedId = P.request?.id;
        if (!expectedId) throw pairingChanged();
        const result = await pairDeadline(trackPairWrite('/pair-requests/cancel', {}, expectedId));
        if (!pairCurrent(epoch)) return;
        const request = verifyPairRequest(result.request, expectedId);
        if (request.status === 'connected') {
          if (!result.device?.id || typeof result.csrf !== 'string' || !result.csrf) throw new Error('Missing approved session');
          P.claimedDeviceId = result.device.id;
          renderPairFlow('already-connected', tr('取消前电脑已批准并完成连接。你可以继续，或退出此连接。', 'The connection completed before cancellation. You can continue or disconnect this device.'));
        } else if (['denied', 'canceled', 'expired', 'revoked'].includes(request.status)) await applyPairStatus(result);
        else throw new Error('Unknown cancellation result');
      }
    } catch (error) {
      if (!pairCurrent(epoch)) return;
      if (error.code === 'MOBILE_PAIRING_CHANGED') showPairingChanged();
      else if ((disconnect && error.status === 401) || (!disconnect && error.status === 404)) {
        resetPairFlow(); renderPairFlow('retry', pairNotFound());
      } else renderPairFlow(disconnect ? 'already-connected' : 'cancel-unknown',
        disconnect ? tr('未能确认是否退出连接。可以重试。', 'Could not confirm disconnection. You can try again.')
          : tr('未能确认是否取消。请重试取消。', 'Could not confirm cancellation. Try canceling again.'));
    }
  });
  $('chat-form').addEventListener('submit', async event => {
    event.preventDefault(); if (!S.device || S.sending || $('chat-send').disabled) return;
    const value = $('chat-input').value; if (!value.trim() || value.length > 6000) return;
    const botId = S.botId, device = S.device, requestId = 'r_' + crypto.randomUUID().replaceAll('-', '');
    // Persist the request identity before any network side effect. On reload,
    // only read the existing receipt; never manufacture a new retry identity.
    try {
      S.pending[botId] = { id: requestId, text: value, createdAt: Date.now(), draft: '' };
      persistPending();
    } catch (_) {
      delete S.pending[botId];
      S.sendError = tr('浏览器无法保存发送记录，消息尚未发送。', 'The browser could not save the request record. Nothing was sent.');
      renderChat(); return;
    }
    $('chat-input').value = '';
    fitComposer(); closeEmoji(); S.sending = true; S.sendError = ''; renderChat();
    try {
      const result = await raw('/requests', 'POST', { botId, requestId, text: value });
      if (S.device !== device) return;
      if (S.botId === botId && pendingId(botId) === requestId && result.request.status !== 'unconfirmed' &&
          !S.requests.some(request => request.requestId === requestId)) {
        S.mutation++;
        S.requests = [...S.requests, result.request];
      }
      // Keep the local bubble until the history read installs the durable one.
    } catch (error) {
      if (S.device !== device || pendingId(botId) !== requestId) return;
      if (error.status === 401) {
        try { await read('/session'); } catch (_) {}
        if (S.device !== device) return;
      }
      // A remote target or scope can change after the host has stored this request.
      // Only pre-admission conflict codes prove that no receipt was created.
      const rejected = [400, 413, 429].includes(error.status) ||
        ['MOBILE_BOT_BUSY', 'MOBILE_RECEIPT_LIMIT', 'MOBILE_CSRF'].includes(error.code);
      if (!error.uncertain && rejected) {
        settlePending(botId, requestId, { restore: true });
        if (S.botId === botId) S.sendError = error.code === 'MOBILE_BOT_BUSY'
          ? tr('Bot 正忙，请先处理原任务。', 'This Bot is busy. Check the current task first.')
          : tr('未接受这条消息，请检查连接与权限。', 'This message was not accepted. Check the connection and permissions.');
      } else networkError(error);
    } finally {
      if (S.device === device) { S.sending = false; renderChat(); void refresh(); }
    }
  });
  $('chat-stop').addEventListener('click', async () => {
    const request = S.requests.findLast(r => active(r));
    if (!request || $('chat-stop').disabled) return;
    const generation = S.generation;
    const stop = { requestId: request.requestId, botId: request.botId, streamId: request.streamId, phase: 'sending' };
    S.stops.set(stop.botId, stop); renderChat();
    const current = () => generation === S.generation && S.botId === stop.botId && S.stops.get(stop.botId) === stop;
    try {
      const result = await raw('/requests/' + request.requestId + '/cancel', 'POST', { botId: request.botId }, true);
      if (!current()) return;
      const receipt = result?.request;
      if (typeof result?.ok !== 'boolean' || !receipt || receipt.requestId !== stop.requestId || receipt.botId !== stop.botId ||
          typeof stop.streamId !== 'string' || !stop.streamId || receipt.streamId !== stop.streamId ||
          result.ok === false && !['canceling', 'unconfirmed'].includes(receipt.status)) {
        stop.phase = 'unknown';
        return;
      }
      stop.phase = 'acknowledged';
      S.mutation++;
      S.requests = S.requests.map(row => row.requestId === stop.requestId && row.botId === stop.botId && row.streamId === stop.streamId ? receipt : row);
    } catch (error) {
      if (!current()) return;
      stop.phase = 'unknown'; networkError(error);
    } finally {
      if (current()) { renderChat(); void refresh(); }
      // A switched-away request still needs history reconciliation when revisited.
      else if (S.stops.get(stop.botId) === stop) stop.phase = 'unknown';
    }
  });
  $('chat-review').addEventListener('click', async () => {
    const botId = S.botId, generation = S.generation;
    const requestId = pendingId(botId) || unreviewedReceipt()?.requestId;
    if (!requestId) return;
    $('chat-review').disabled = true;
    try {
      let receipt;
      try {
        ({ request: receipt } = await read('/requests/' + requestId + '?botId=' + encodeURIComponent(botId)));
      } catch (error) { if (error.status !== 404) throw error; }
      if (generation !== S.generation) return;
      if (receipt && active(receipt)) { await refresh(); return; }
      const entry = S.pending[botId];
      let message;
      if (pendingId(botId) === requestId) {
        const streamId = receipt?.streamId || entry?.streamId;
        if (streamId) {
          const history = await read('/bots/' + encodeURIComponent(botId) + '/history');
          if (generation !== S.generation || pendingId(botId) !== requestId) return;
          const latest = history.requests.find(row => row.requestId === requestId);
          if (latest && active(latest)) { await refresh(); return; }
          message = sentMessage(streamId, history.messages);
        }
        if (!message && entry?.text && entry.draft && entry.text !== entry.draft) {
          window.alert(tr('输入框还有另一份草稿。请先复制或清空那份草稿，再恢复这条消息。', 'The input holds another draft. Copy or clear it before restoring this message.'));
          return;
        }
      }
      if (!window.confirm(tr('请先在电脑核查原任务是否已执行。确认后仅解除发送限制，不会重新发送原消息。继续？', 'First check the original task on your computer. Continue only after reviewing it. This unlocks the input and does not resend the message. Continue?'))) return;
      if (S.stops.get(botId)?.requestId === requestId) S.stops.delete(botId);
      settlePending(botId, requestId, { restore: !message, message });
      S.reviewed = [...S.reviewed.filter(id => id !== requestId), requestId].slice(-100);
      save('reviewed.' + S.device.id, S.reviewed); renderChat();
    } catch (error) { networkError(error); }
    finally { $('chat-review').disabled = false; }
  });
  $('bot-search').addEventListener('input', renderBots);
  $('bot-search-clear').addEventListener('click', () => {
    $('bot-search').value = '';
    renderBots();
    $('bot-search').focus({ preventScroll: true });
  });
  $('chat-input').addEventListener('input', () => {
    const pinned = atLatest();
    fitComposer(); saveDraft();
    if (pinned) jumpLatest();
  });
  $('chat-input').addEventListener('click', () => {
    if (!$('emoji-tray').hidden) closeEmoji();
  });
  function closeEmoji() {
    $('emoji-tray').hidden = true;
    $('emoji-toggle').setAttribute('aria-expanded', 'false');
    $('emoji-toggle').setAttribute('aria-label', tr('插入表情', 'Insert emoji'));
    $('chat-form').parentElement.dataset.emojiOpen = 'false';
  }
  $('emoji-toggle').addEventListener('click', () => {
    if (!$('emoji-tray').hidden) { closeEmoji(); return; }
    const pinned = atLatest();
    $('emoji-tray').hidden = false;
    $('emoji-toggle').setAttribute('aria-expanded', 'true');
    $('emoji-toggle').setAttribute('aria-label', tr('收起表情', 'Close emoji'));
    $('chat-form').parentElement.dataset.emojiOpen = 'true';
    if (pinned) jumpLatest();
  });
  for (const [emoji, zh, en] of quickEmoji) {
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'emoji-option';
    button.textContent = emoji; button.setAttribute('aria-label', tr(zh, en));
    button.addEventListener('click', () => {
      const input = $('chat-input');
      if (input.disabled) return;
      const start = input.selectionStart, end = input.selectionEnd;
      if (input.value.length - (end - start) + emoji.length > input.maxLength) return;
      closeEmoji();
      input.setRangeText(emoji, start, end, 'end');
      input.focus({ preventScroll: true });
      input.dispatchEvent(new Event('input', { bubbles: true }));
    });
    $('emoji-tray').append(button);
  }
  $('emoji-toggle').addEventListener('pointerdown', event => {
    if (document.activeElement === $('chat-input')) event.preventDefault();
  });
  $('emoji-tray').addEventListener('pointerdown', event => {
    if (document.activeElement === $('chat-input')) event.preventDefault();
  });
  $('chat-view').addEventListener('keydown', event => {
    if (event.key !== 'Escape' || $('emoji-tray').hidden) return;
    closeEmoji();
    if (document.activeElement !== $('chat-input')) $('emoji-toggle').focus();
  });
  $('chat-messages').addEventListener('scroll', updateLatest, { passive: true });
  $('chat-latest').addEventListener('click', jumpLatest);
  $('chat-back').addEventListener('click', () => {
    closeEmoji(); saveDraft();
    if (atLatest()) scrollByBot.delete(S.botId);
    else scrollByBot.set(S.botId, $('chat-messages').scrollTop);
    S.generation++; S.botId = ''; show('connected-view');
    ([...$('bot-list').children].find(row => row.dataset.botId === S.lastBotButton) || $('connected-title')).focus({ preventScroll: true });
    void refresh();
  });
  // Android can resize the layout viewport, while Safari can resize only
  // the visual viewport. Remember the resting height for the current width.
  const viewport = window.visualViewport;
  let viewportWidth = window.innerWidth, restingHeight = window.innerHeight;
  function sizeForKeyboard() {
    const pinned = S.botId && $('chat-jump').hidden;
    const app = $('mobile-web-app');
    if (viewportWidth !== window.innerWidth) {
      viewportWidth = window.innerWidth;
      restingHeight = window.innerHeight;
    }
    restingHeight = Math.max(restingHeight, window.innerHeight);
    const zoomed = viewport && viewport.scale !== 1;
    const height = !zoomed && viewport ? viewport.height : window.innerHeight;
    const imeOpen = !zoomed && restingHeight - height > 80 &&
      (document.activeElement === $('chat-input') || $('chat-footer').dataset.imeOpen === 'true');
    $('chat-footer').dataset.imeOpen = String(imeOpen);
    if (imeOpen && window.innerHeight - height > 80) {
      app.style.setProperty('--keyboard-height', Math.round(height) + 'px');
    } else app.style.removeProperty('--keyboard-height');
    if (pinned) jumpLatest();
    else if (S.botId) updateLatest();
  }
  viewport?.addEventListener('resize', sizeForKeyboard);
  window.addEventListener('resize', sizeForKeyboard);
  $('reconnect-button').addEventListener('click', () => { S.failures = 0; void refresh(); });
  $('logout').addEventListener('click', async () => {
    try {
      await pairDeadline(trackPairWrite('/logout', {})); clearPrivate(); resetPairFlow(); show('pairing-view');
      renderPairFlow('retry', tr('已退出连接。可以重新请求连接。', 'Disconnected. You can request access again.'));
    }
    catch (error) { networkError(error); }
  });
  function suspend() { saveDraft(); clearTimeout(S.timer); clearTimeout(P.timer); }
  function pausePage() {
    suspend();
    if (S.device) return;
    P.paused = true; P.epoch++; P.checking = false;
    P.resumeCheck = ['checking', 'sending', 'qr-sending'].includes(P.phase);
    if (P.phase === 'canceling') renderPairFlow('cancel-unknown', tr('未能确认是否取消。请重试取消。', 'Could not confirm cancellation. Try canceling again.'));
    else if (P.phase === 'disconnecting') renderPairFlow('already-connected', tr('未能确认是否退出连接。可以重试。', 'Could not confirm disconnection. You can try again.'));
  }
  function resume() {
    if (document.hidden || P.paused) return;
    if (S.device) { S.failures = 0; void refresh(); }
    else if (P.resumeCheck || P.phase === 'checking' && !P.checking) void restorePairFlow();
    else if (P.phase === 'waiting') nextPairPoll();
  }
  window.addEventListener('pagehide', pausePage);
  window.addEventListener('pageshow', () => { P.paused = false; resume(); });
  window.addEventListener('online', resume); window.addEventListener('offline', () => networkError());
  document.addEventListener('visibilitychange', () => document.hidden ? suspend() : resume());
  document.querySelectorAll('[data-i18n-text-zh]').forEach(el => { el.textContent = el.getAttribute(english ? 'data-i18n-text-en' : 'data-i18n-text-zh'); });
  for (const attribute of ['placeholder', 'aria-label']) document.querySelectorAll('[data-i18n-' + attribute + '-zh]').forEach(el => {
    el.setAttribute(attribute, el.getAttribute('data-i18n-' + attribute + (english ? '-en' : '-zh')));
  });
  document.documentElement.lang = english ? 'en' : 'zh-CN';
  $('pair-device-name').value = defaultDeviceName();
  window.addEventListener('hashchange', () => {
    const token = consumePairingLink();
    if (S.device || !token) return;
    pairingToken = token;
    resetPairFlow(); void restorePairFlow();
  });
  paintAvatar($('pair-companion'), { avatar: 'peek' }, 76, 'idle');
  show('pairing-view');
  void restorePairFlow();
})();
