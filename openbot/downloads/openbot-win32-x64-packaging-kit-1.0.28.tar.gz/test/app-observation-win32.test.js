'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');

const { WinAppCapture } = require('../plugins/desktop-capture/lib/app-observation-win32.cjs');

const img = (empty = false) => ({ isEmpty: () => empty, toPNG: () => Buffer.from(empty ? '' : 'png'), getSize: () => ({ width: 1920, height: 1080 }) });
const screenSource = (id, label) => ({ id: 'screen:' + id, display_id: String(id), name: 'Screen ' + id, thumbnail: img() });
const windowSource = (id, name) => ({ id: 'window:' + id, name, thumbnail: img() });
const TARGET_ID = /^[a-f0-9]{32}$/;

function makeElectron({ sources = [], displays = [{ id: 1, label: 'Primary' }] } = {}) {
  return {
    desktopCapturer: { getSources: async () => sources },
    screen: { getCursorScreenPoint: () => ({ x: 0, y: 0 }), getDisplayNearestPoint: () => displays[0] }
  };
}
function fixture(t, opts = {}) {
  const electron = makeElectron(opts.electron || {});
  const capture = new WinAppCapture({ electron, platform: opts.platform || 'win32', now: () => opts.now || 1000 });
  t.after(async () => { await capture.close(); });
  return { capture, electron };
}

test('status reports supported with granted permission on win32', t => {
  const { capture } = fixture(t, { platform: 'win32' });
  assert.deepEqual(capture.status(), { supported: true, screenPermission: 'granted' });
});

test('non-win32 backend reports unsupported and refuses capture', async t => {
  const { capture } = fixture(t, { platform: 'linux' });
  assert.deepEqual(capture.status(), { supported: false, screenPermission: 'unsupported' });
  await assert.rejects(() => capture.capture('screen', {}), err => err.code === 'APP_OBSERVATION_UNAVAILABLE');
  await assert.rejects(() => capture.listApplications({}), err => err.code === 'APP_OBSERVATION_UNAVAILABLE');
});

test('screen capture returns an image and metadata', async t => {
  const { capture } = fixture(t, { electron: { sources: [screenSource(1, 'Primary'), windowSource(7, 'Notepad')] } });
  const out = await capture.capture('screen', {});
  assert.ok(out.image && !out.image.isEmpty());
  assert.equal(out.metadata.source, 'screen');
  assert.equal(out.metadata.sourceLabel, '当前屏幕');
});

test('application capture resolves a listed target', async t => {
  const { capture } = fixture(t, { electron: { sources: [windowSource(7, 'Notepad'), windowSource(9, 'Calculator')] } });
  const list = await capture.listApplications({});
  assert.equal(list.ok, true);
  const target = list.applications.find(a => a.name === 'Notepad');
  assert.ok(target && TARGET_ID.test(target.targetId));
  const out = await capture.capture('application', { targetId: target.targetId });
  assert.ok(out.image && !out.image.isEmpty());
  assert.equal(out.metadata.source, 'application');
  assert.equal(out.metadata.targetName, 'Notepad');
});

test('listApplications returns opaque, stable targetIds without pixels', async t => {
  const { capture } = fixture(t, { electron: { sources: [windowSource(7, 'Notepad'), windowSource(9, 'Calculator'), windowSource(11, 'OpenBot')] } });
  const first = await capture.listApplications({});
  const second = await capture.listApplications({});
  assert.deepEqual(first, second);
  assert.deepEqual(first.applications.map(a => a.name), ['Notepad', 'Calculator', 'OpenBot']);
  for (const a of first.applications) {
    assert.match(a.targetId, TARGET_ID);
    assert.deepEqual(Object.keys(a).sort(), ['name', 'targetId', 'windowTitle']);
  }
  assert.equal(new Set(first.applications.map(a => a.targetId)).size, 3);
});

test('empty thumbnail is reported as APP_OBSERVATION_EMPTY', async t => {
  const sources = [screenSource(1, 'Primary')].map(s => ({ ...s, thumbnail: img(true) }));
  const { capture } = fixture(t, { electron: { sources } });
  await assert.rejects(() => capture.capture('screen', {}), err => err.code === 'APP_OBSERVATION_EMPTY');
});

test('unknown application target is unavailable', async t => {
  const { capture } = fixture(t, { electron: { sources: [windowSource(7, 'Notepad')] } });
  await assert.rejects(() => capture.capture('application', { targetId: 'a'.repeat(32) }), err => err.code === 'APP_OBSERVATION_UNAVAILABLE');
});

test('invalid source is rejected', async t => {
  const { capture } = fixture(t, {});
  await assert.rejects(() => capture.capture('bogus', {}), err => err.code === 'APP_OBSERVATION_INVALID');
});
