import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { packager } from '@electron/packager';
// Windows 打包与 mac 共用同一份 asar 布局（package-mac.mjs 的 main-guard 使
// 这里的 import 无副作用）。Windows 清单（build-info.json 的 win 版生成与
// TeamAI 锁封存）尚未建立：build-manifest.js 目前是 darwin 专属
// （platform/arch 写死、还哈希 mac 专属 native/browser-ocr 二进制），
// 待 Windows 发布链路建立时补齐，先如实留空。
import { desktopAsarOptions } from './package-mac.mjs';

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [snapshot, name, out, electronVersion, electronZipDir, ...extra] = process.argv.slice(2);
  assert(snapshot && name && out && electronVersion && !extra.length, 'usage: package-win.mjs <snapshot> <name> <out> <electronVersion> [electronZipDir]');
  assert.equal(process.platform === 'win32' || process.platform === 'darwin', true, 'package-win runs on the target Windows host or the mac dev slot');
  const icon = path.resolve('build', 'icon.ico');
  assert(fs.lstatSync(icon).isFile() && fs.lstatSync(icon).size > 0, 'build/icon.ico missing; run node scripts/make-icon-win.cjs first');
  const pkg = JSON.parse(fs.readFileSync(path.join(snapshot, 'package.json')));
  const outputs = await packager({
    dir: snapshot, name, out, electronVersion,
    platform: 'win32', arch: 'x64', icon,
    appVersion: pkg.version,
    // Explorer 属性页与任务栏悬浮显示的产品信息。CompanyName 必须显式给：
    // packager 在 win32 下缺 CompanyName 时会强制要求 package.json 的
    // author 字段（源 package.json 没有 author）。
    win32metadata: { CompanyName: pkg.productName || name, ProductName: pkg.productName || name, FileDescription: pkg.description || pkg.productName || name },
    asar: desktopAsarOptions, prune: false,
    ...(electronZipDir ? { electronZipDir } : {}),
    ignore: ['^/dist', '^/scripts', '^/build/', '^/test', '^/docs', '^/work', '^/outputs', '^/\\.git', '\\.DS_Store'],
  });
  console.log('Wrote new app to: ' + outputs.join(', '));
}
