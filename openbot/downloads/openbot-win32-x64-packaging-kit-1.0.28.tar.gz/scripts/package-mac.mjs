import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { packager } from '@electron/packager';

const lockName = 'integrations/teamai/package-lock.json';
const digest = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
export const desktopAsarOptions = Object.freeze({
  unpackDir: '{node_modules,vendor/dsh-superterminal-openbot,vendor/codexhome-manager/bin,vendor/cua-driver,native,bin}',
  unpack: '**/src/{desktop-plugin-worker,desktop-plugin-contract}.js',
});

// Packager drops installation lockfiles at every depth. This optional backend's
// lock is a fingerprinted distribution input, so restore only that exact file
// from the frozen snapshot before ASAR creation; keep all default exclusions.
export function preserveTeamLock(snapshot) {
  const source = path.join(snapshot, lockName);
  const build = JSON.parse(fs.readFileSync(path.join(snapshot, 'build-info.json')));
  const expected = build.files[lockName];
  assert.match(expected, /^[a-f0-9]{64}$/);
  assert(fs.lstatSync(source).isFile() && !fs.lstatSync(source).isSymbolicLink());
  assert.equal(digest(fs.readFileSync(source)), expected);
  return async ({ buildPath }) => {
    const target = path.join(buildPath, lockName);
    assert(fs.lstatSync(path.dirname(target)).isDirectory());
    assert.equal(digest(fs.readFileSync(source)), expected, 'Frozen TeamAI lock changed');
    fs.copyFileSync(source, target, fs.constants.COPYFILE_EXCL);
    assert.equal(digest(fs.readFileSync(target)), expected, 'Packaged TeamAI lock changed');
  };
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const [snapshot, name, out, electronVersion, extendInfo, electronZipDir, ...extra] = process.argv.slice(2);
  assert(snapshot && name && out && electronVersion && extendInfo && !extra.length);
  const outputs = await packager({
    dir: snapshot, name, out, electronVersion, extendInfo,
    platform: 'darwin', arch: 'arm64', icon: path.resolve('build/icon.icns'),
    appBundleId: 'app.openbot.desktop', appVersion: JSON.parse(fs.readFileSync(path.join(snapshot, 'package.json'))).version,
    asar: desktopAsarOptions, prune: false,
    ...(electronZipDir ? { electronZipDir } : {}),
    ignore: ['^/dist', '^/scripts', '^/build/', '^/test', '^/docs', '^/work', '^/outputs', '^/\\.git', '\\.DS_Store'],
    afterCopy: [preserveTeamLock(snapshot)],
  });
  console.log('Wrote new app to: ' + outputs.join(', '));
}
