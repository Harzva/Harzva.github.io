'use strict';
// 共享 OB 矢量 → 多尺寸 icon.ico（Windows 打包用）。
// 与 make-icons.sh 同源：从 build/icon.png 用 sips 缩放，再用纯 Node 组 ICO 容器。
// ICO 条目使用 PNG 载荷（Windows Vista+ 任意尺寸都按 PNG 渲染；目标平台为 Win10/11）。
// 写完后自校验：逐条解析回读，校验数量、PNG 签名与声明尺寸一致。
const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');

const SIZES = [16, 24, 32, 48, 64, 128, 256];
const root = path.resolve(__dirname, '..');
const source = path.join(root, 'build', 'icon.png');
const target = path.join(root, 'build', 'icon.ico');

if (!fs.existsSync(source)) throw new Error('missing build/icon.png; run the shared vector pipeline first');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'openbot-ico-'));
let pngs;
try {
  pngs = SIZES.map(size => {
    const out = path.join(tmp, `icon-${size}.png`);
    execFileSync('sips', ['-z', String(size), String(size), source, '--out', out], { stdio: ['ignore', 'ignore', 'ignore'] });
    return { size, data: fs.readFileSync(out) };
  });
} finally { fs.rmSync(tmp, { recursive: true, force: true }); }

// ICO 容器：6 字节头 + 每条 16 字节目录 + PNG 载荷。宽高字节 0 表示 256。
const header = Buffer.alloc(6);
header.writeUInt16LE(0, 0); header.writeUInt16LE(1, 2); header.writeUInt16LE(pngs.length, 4);
let offset = 6 + 16 * pngs.length;
const entries = [];
for (const { size, data } of pngs) {
  const entry = Buffer.alloc(16);
  const declared = size >= 256 ? 0 : size;
  entry.writeUInt8(declared, 0); entry.writeUInt8(declared, 1);
  entry.writeUInt8(0, 2); entry.writeUInt8(0, 3);
  entry.writeUInt16LE(1, 4);      // planes
  entry.writeUInt16LE(32, 6);     // bit count
  entry.writeUInt32LE(data.length, 8);
  entry.writeUInt32LE(offset, 12);
  entries.push(entry);
  offset += data.length;
}
fs.writeFileSync(target, Buffer.concat([header, ...entries, ...pngs.map(p => p.data)]));

// Self-check: parse the container back; every entry must be a PNG whose IHDR
// dimensions match the directory declaration. A broken container must fail
// the build here, not surface as an invisible icon on Windows.
const ico = fs.readFileSync(target);
if (ico.readUInt16LE(2) !== 1) throw new Error('ico type must be 1');
const count = ico.readUInt16LE(4);
if (count !== SIZES.length) throw new Error(`ico entry count mismatch: ${count}`);
for (let i = 0; i < count; i++) {
  const e = ico.subarray(6 + 16 * i, 6 + 16 * (i + 1));
  const bytes = e.readUInt32LE(8), at = e.readUInt32LE(12);
  const png = ico.subarray(at, at + bytes);
  if (png.length !== bytes || png[0] !== 0x89 || png[1] !== 0x50 || png[2] !== 0x4e || png[3] !== 0x47) throw new Error(`entry ${i} is not a complete PNG`);
  const width = png.readUInt32BE(16), height = png.readUInt32BE(20); // IHDR
  const declared = e.readUInt8(0) === 0 ? 256 : e.readUInt8(0);
  if (width !== declared || height !== declared) throw new Error(`entry ${i} size mismatch: ${width}x${height} vs ${declared}`);
}
console.log('icon.ico ready (' + SIZES.join(',') + ')');
